Kevin Nella
"Best" Task README

This task follows the reference trajectory for picking and placing a cube with the initial and final locations as mentioned in the project prompt. The controller implemented for this solution was a Feedforward + Proportional Feedback controller. The Proportional gain Kp was set to 3.0 * 6x6 Identity matrix.