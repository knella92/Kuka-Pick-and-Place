Kevin Nella
"Overshoot" Task README

This task follows the same reference trajectory as the "best" task. The controller implemented for this solution was a Feedforward + Proportional + Integral Feedback controller. The Proportional gain Kp was set to 5.0 * 6x6 Identity matrix, and the Integral gain Ki was set to 15.0 * 6x6 Identity matrix.